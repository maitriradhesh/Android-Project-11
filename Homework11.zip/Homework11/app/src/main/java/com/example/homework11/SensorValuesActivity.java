package com.example.homework11;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class SensorValuesActivity extends Activity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor sensor;
    private TextView value1, sensorAccuracy, timeStamp, value2, value3, value4, value5, value6, value7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_values);

        Intent intent = getIntent();
        int sensorType = intent.getIntExtra("sensorType", 0);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(sensorType);

        // Initialize your TextViews here with findViewById()
        value1 = findViewById(R.id.value1);
        sensorAccuracy = findViewById(R.id.sensor_accuracy);
        timeStamp = findViewById(R.id.time_stamp);
        value2 = findViewById(R.id.value2); // Make sure you have these views in your layout
        value3 = findViewById(R.id.value3);
        value4 = findViewById(R.id.value4);
        value5 = findViewById(R.id.value5);
        value6 = findViewById(R.id.value6);
        value7 = findViewById(R.id.value7);
    }
    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
    }
    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Handle accuracy changes if needed
    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        value1.setText(String.valueOf(event.values[0]));
        sensorAccuracy.setText(String.valueOf(event.accuracy));
        timeStamp.setText(String.valueOf(event.timestamp));

        if (event.values.length > 1) {
            value2.setText(String.valueOf(event.values[1]));
        }
        if (event.values.length > 2) {
            value3.setText(String.valueOf(event.values[2]));
        }
        if (event.values.length > 3) {
            value4.setText(String.valueOf(event.values[3]));
        }
        if (event.values.length > 4) {
            value5.setText(String.valueOf(event.values[4]));
        }
        if (event.values.length > 5) {
            value6.setText(String.valueOf(event.values[5]));
        }
        if (event.values.length > 6) {
            value7.setText(String.valueOf(event.values[6]));
        }
    }
}
