package com.example.homework11;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    private List<Sensor> arrayList;
    private Context context;
    public Adapter(List<Sensor> modelObjectArrayList) { this.arrayList = modelObjectArrayList;}
    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter, parent, false);
        return new ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder holder, final int position) {
        Sensor sensor = arrayList.get(position);
        holder.textName.setText(sensor.getName());
        holder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(context, DetailsActivity.class);
            intent.putExtra("sensorType", sensor.getType());
            context.startActivity(intent);
        });
    }
    @Override
    public int getItemCount() { return arrayList != null ? arrayList.size() : 0;}
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textName;
        View itemView;
        public ViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            this.textName = itemView.findViewById(R.id.text_name);
        }
    }
}
