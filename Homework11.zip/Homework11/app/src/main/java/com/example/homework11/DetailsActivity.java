package com.example.homework11;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class DetailsActivity extends AppCompatActivity {
    private int sensorType;
    private TextView sensorName;
    private TextView sensorRange;
    private TextView sensorMindelay;
    private TextView sensorPower;
    private TextView sensorResolution;
    private TextView sensorVendor;
    private TextView sensorVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        Intent intent = getIntent();
        sensorType = intent.getIntExtra("sensorType", 0);
        SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Sensor sensor = sensorManager.getDefaultSensor(sensorType);

        // Assuming you have TextViews with the respective ids in your activity_details.xml
        sensorName = findViewById(R.id.sensor_Name1);
        sensorRange = findViewById(R.id.sensor_range);
        sensorMindelay = findViewById(R.id.sensor_mindelay);
        sensorPower = findViewById(R.id.sensor_power);
        sensorResolution = findViewById(R.id.sensor_resolution);
        sensorVendor = findViewById(R.id.sensor_vendor);
        sensorVersion = findViewById(R.id.sensor_version);

        sensorName.setText(sensor.getName());
        sensorRange.setText(String.valueOf(sensor.getMaximumRange()));
        sensorMindelay.setText(String.valueOf(sensor.getMinDelay()));
        sensorPower.setText(String.valueOf(sensor.getPower()));
        sensorResolution.setText(String.valueOf(sensor.getResolution()));
        sensorVendor.setText(sensor.getVendor());
        sensorVersion.setText(String.valueOf(sensor.getVersion()));
    }
    public void GetSensorValue(View v) {
        Intent intent = new Intent(this, SensorValuesActivity.class);
        intent.putExtra("sensorType", sensorType);
        startActivity(intent);
    }
}
